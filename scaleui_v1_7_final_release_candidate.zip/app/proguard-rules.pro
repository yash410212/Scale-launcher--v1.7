# Scale UI uses AndroidX/Compose; no custom keep rules are required yet.
# Keep the launcher Activity and platform services discoverable by Android.
-keep class com.scaleui.launcher.core.MainActivity { *; }
-keep class com.scaleui.launcher.core.media.ScaleNotificationListenerService { *; }
-keep class com.scaleui.launcher.core.admin.ScaleDeviceAdminReceiver { *; }
-keep class com.scaleui.launcher.core.accessibility.ScaleAccessibilityService { *; }
