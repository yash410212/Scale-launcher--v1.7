plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.scaleui.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.scaleui.launcher"
        minSdk = 26          // Android 8.0+ — covers ~95% of active devices, needed for adaptive icons
        targetSdk = 34
        versionCode = 9
        versionName = "1.7.0"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Core + Compose
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation") // HorizontalPager (Part 3+)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended") // covers Search/Tune/Pause/PlayArrow/SkipNext etc.

    // Navigation (used by ScaleNavHost from Part 3 onward)
    implementation("androidx.navigation:navigation-compose:2.7.7")

    // Lifecycle / ViewModel
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")

    // Coroutines (used by AppRepository for background app-list loading)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Persisted settings (Part 11+): theme mode, grid size, icon shape
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
