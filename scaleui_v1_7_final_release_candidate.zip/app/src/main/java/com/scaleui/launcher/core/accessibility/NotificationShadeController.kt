package com.scaleui.launcher.core.accessibility

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Opens the notification panel when the optional accessibility bridge is active. */
object NotificationShadeController {
    fun open(context: Context): Boolean {
        if (ScaleAccessibilityService.openNotificationPanel()) return true
        return runCatching {
            context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        }.getOrDefault(false)
    }
}
