package com.scaleui.launcher.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.toBitmapCached
import com.scaleui.launcher.theme.GlassSurface
import com.scaleui.launcher.theme.LocalGlassConfig
import com.scaleui.launcher.theme.LocalIconShape
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * First-run reference layout. It is a visual preset, not a fake live-data
 * screen: sample widgets are explicitly labelled as preview content.
 */
@Composable
fun PreSetupHomeScreen(
    apps: List<AppInfo>,
    modifier: Modifier = Modifier,
) {
    val glass = LocalGlassConfig.current
    val sample = remember(apps) { apps.sortedBy { it.label.lowercase(Locale.getDefault()) }.take(12) }
    val today = remember { LocalDate.now() }
    val now = remember { LocalTime.now() }
    val weekday = remember(today) { today.format(DateTimeFormatter.ofPattern("EEEE", Locale.getDefault())) }
    val date = remember(today) { today.format(DateTimeFormatter.ofPattern("MMMM d", Locale.getDefault())) }
    val time = remember(now) { now.format(DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault())) }
    val greeting = remember(now) {
        when (now.hour) {
            in 5..11 -> "Good morning"
            in 12..16 -> "Good afternoon"
            in 17..21 -> "Good evening"
            else -> "Good night"
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(30.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        glass.accentColor.copy(alpha = 0.16f),
                        Color.Black.copy(alpha = 0.10f),
                        glass.backgroundTint.copy(alpha = 0.20f),
                    )
                )
            )
            .border(0.8.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(30.dp))
            .padding(horizontal = 13.dp, vertical = 10.dp),
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    Text(
                        time,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .94f),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(
                        "$greeting  •  Home preview",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .48f),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(glass.accentColor.copy(alpha = .09f))
                        .border(.8.dp, Color.White.copy(alpha = .14f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.DarkMode, null, tint = glass.accentColor.copy(alpha = .82f), modifier = Modifier.size(14.dp))
                }
            }

            GlassSurface(
                modifier = Modifier.fillMaxWidth().height(138.dp),
                shape = RoundedCornerShape(26.dp),
                alphaOverride = (glass.tintAlpha * 1.15f).coerceAtMost(.28f),
            ) {
                Box(Modifier.fillMaxSize()) {
                    // Small optical halo makes the hero card feel like a glass lens.
                    Box(
                        Modifier
                            .size(150.dp)
                            .align(Alignment.TopEnd)
                            .background(
                                Brush.radialGradient(
                                    listOf(glass.accentColor.copy(alpha = .10f), Color.Transparent)
                                )
                            )
                    )
                    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Text(weekday, color = MaterialTheme.colorScheme.onSurface.copy(.58f), style = MaterialTheme.typography.labelLarge)
                            Text(time, color = MaterialTheme.colorScheme.onSurface.copy(.54f), style = MaterialTheme.typography.labelMedium)
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(date, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Light)
                        Spacer(Modifier.weight(1f))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(glass.accentColor.copy(.78f)))
                            Text("Widgets", color = MaterialTheme.colorScheme.onSurface.copy(.58f), style = MaterialTheme.typography.labelSmall)
                            Spacer(Modifier.weight(1f))
                            Text("Scale UI Launcher", color = MaterialTheme.colorScheme.onSurface.copy(.40f), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PreviewInfoCard(Icons.Default.Cloud, "Weather", "Preview")
                PreviewInfoCard(Icons.Default.MusicNote, "Music", "Preview")
                PreviewInfoCard(Icons.Default.BatteryFull, "Battery", "Preview")
            }

            val rows = sample.chunked(4)
            rows.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    row.forEach { app ->
                        val bitmap = remember(app.packageName) { app.icon.toBitmapCached() }
                        Column(
                            Modifier.weight(1f),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            Box(
                                Modifier
                                    .size(48.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color.White.copy(.065f))
                                    .border(.8.dp, Color.White.copy(.12f), RoundedCornerShape(16.dp)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Image(
                                    BitmapPainter(bitmap.asImageBitmap()),
                                    app.label,
                                    Modifier.size(41.dp).clip(LocalIconShape.current.toComposeShape()),
                                )
                            }
                            Text(
                                app.label,
                                color = MaterialTheme.colorScheme.onSurface.copy(.76f),
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            Spacer(Modifier.weight(1f))
            GlassSurface(
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = RoundedCornerShape(24.dp),
                alphaOverride = (glass.tintAlpha * 1.05f).coerceAtMost(.24f),
            ) {
                Row(Modifier.fillMaxSize().padding(horizontal = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Search, null, tint = MaterialTheme.colorScheme.onSurface.copy(.64f), modifier = Modifier.size(17.dp))
                    Text("Search apps", color = MaterialTheme.colorScheme.onSurface.copy(.56f), style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(start = 8.dp))
                    Spacer(Modifier.weight(1f))
                    Text("App Drawer", color = MaterialTheme.colorScheme.onSurface.copy(.36f), style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun PreviewInfoCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String) {
    val glass = LocalGlassConfig.current
    GlassSurface(
        modifier = Modifier.weight(1f).height(54.dp),
        shape = RoundedCornerShape(17.dp),
        alphaOverride = (glass.tintAlpha * .92f).coerceAtMost(.20f),
    ) {
        Row(Modifier.fillMaxSize().padding(horizontal = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = glass.accentColor.copy(.72f), modifier = Modifier.size(16.dp))
            Column(Modifier.padding(start = 7.dp)) {
                Text(title, color = MaterialTheme.colorScheme.onSurface.copy(.80f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                Text(value, color = MaterialTheme.colorScheme.onSurface.copy(.42f), style = MaterialTheme.typography.labelSmall, maxLines = 1)
            }
        }
    }
}
