package com.scaleui.launcher.folders

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.toBitmapCached
import com.scaleui.launcher.theme.GlassSurface
import com.scaleui.launcher.theme.LocalGlassConfig

/**
 * Locked design: folder shown on Home as a fanned/overlapping stack of up
 * to 4 icons (rotated/offset) inside a translucent rounded backdrop — not
 * a plain grid-in-circle. Tap opens FolderOpenScreen.
 */
@Composable
fun FolderPreview(folder: ScaleFolder, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pressScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        label = "folderPress",
    )
    Column(
        modifier = modifier.clickable(
            interactionSource = interactionSource,
            indication = androidx.compose.foundation.LocalIndication.current,
            onClick = onClick,
        ).scale(pressScale),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        GlassSurface(
            modifier = Modifier.size(52.dp),
            shape = RoundedCornerShape(16.dp),
            alphaOverride = (LocalGlassConfig.current.tintAlpha * .72f).coerceAtMost(.22f),
        ) {
            val preview = folder.apps.take(4)
            val offsets = listOf(-6f to -6f, 6f to -4f, -4f to 6f, 5f to 5f)
            preview.forEachIndexed { index, app ->
                val (dx, dy) = offsets.getOrElse(index) { 0f to 0f }
                val bitmap = remember(app.packageName) { app.icon.toBitmapCached() }
                Image(
                    painter = BitmapPainter(bitmap.asImageBitmap()),
                    contentDescription = app.label,
                    modifier = Modifier
                        .size(26.dp)
                        .align(Alignment.Center)
                        .offset(dx.dp, dy.dp)
                        .clip(RoundedCornerShape(6.dp)),
                )
            }
        }
        Text(
            text = folder.name,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.size(width = 64.dp, height = 16.dp),
        )
    }
}
