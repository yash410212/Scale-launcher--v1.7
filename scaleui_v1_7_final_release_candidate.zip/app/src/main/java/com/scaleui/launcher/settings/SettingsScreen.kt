package com.scaleui.launcher.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.theme.GlassSurface
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.home.PreSetupHomeScreen
import com.scaleui.launcher.theme.IconShape
import com.scaleui.launcher.theme.ThemeMode
import com.scaleui.launcher.theme.ThemeEngine
import com.scaleui.launcher.profiles.Profile
import com.scaleui.launcher.profiles.ProfileManager
import com.scaleui.launcher.animation.AnimationMode
import com.scaleui.launcher.core.widgets.SystemWidgetHost
import com.scaleui.launcher.core.widgets.SystemWidgetPlacement
import com.scaleui.launcher.data.SettingsRepository
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.launch

/**
 * Settings, per spec section 5: General (Dark/Light) + Home Screen
 * Controls (icon shape, grid size) live here. Theme selection is also
 * here even though spec lists "Theme Settings" as its own sub-section —
 * with only 5 modes total it doesn't need a separate screen yet; splitting
 * it out later is just moving this one Composable, not rewriting it.
 *
 * Widget controls are included here; drawer transparency remains directly accessible from the Drawer.
 */
@Composable
fun SettingsScreen(viewModel: SettingsViewModel, profileManager: ProfileManager, settingsRepository: SettingsRepository, apps: List<AppInfo> = emptyList(), modifier: Modifier = Modifier) {
    val themeMode by viewModel.themeMode.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val iconShape by viewModel.iconShape.collectAsState()
    val gridConfig by viewModel.gridConfig.collectAsState()
    val currentProfile by profileManager.currentProfile.collectAsState()
    val hasPinSet by profileManager.hasPinSet.collectAsState()
    val pinError by profileManager.pinError.collectAsState()
    val animationMode by viewModel.animationMode.collectAsState()
    val homeWidgets by viewModel.homeWidgets.collectAsState()
    var pinInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var newPinInput by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    val context = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var pendingWidgetId by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Int?>(null) }
    val configureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingWidgetId
        if (id != null) {
            if (result.resultCode == Activity.RESULT_OK) {
                val info = SystemWidgetHost.info(context, id)
                val provider = info?.provider?.flattenToString()
                if (provider != null) scope.launch { settingsRepository.addSystemWidget(SystemWidgetPlacement(id, provider)) }
            } else {
                SystemWidgetHost.deleteId(context, id)
            }
            pendingWidgetId = null
        }
    }
    val widgetPickLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val id = pendingWidgetId
        if (id != null) {
            if (result.resultCode == Activity.RESULT_OK) {
                val info = SystemWidgetHost.info(context, id)
                if (info?.configure != null) {
                    configureLauncher.launch(Intent().setComponent(ComponentName(info.provider.packageName, info.configure.className)).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
                } else {
                    val provider = info?.provider?.flattenToString()
                    if (provider != null) scope.launch { settingsRepository.addSystemWidget(SystemWidgetPlacement(id, provider)) }
                    pendingWidgetId = null
                }
            } else {
                SystemWidgetHost.deleteId(context, id)
                pendingWidgetId = null
            }
        }
    }
    val wallpaperLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scope.launch { settingsRepository.setProfileWallpaper(currentProfile, uri.toString()) }
        }
    }
    val wallpaperFlow = androidx.compose.runtime.remember(currentProfile) { settingsRepository.profileWallpaper(currentProfile) }
    val currentWallpaper by wallpaperFlow.collectAsState(initial = null)

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            SettingsSection(title = "General") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Dark theme", style = MaterialTheme.typography.bodyLarge)
                    Switch(checked = isDarkMode, onCheckedChange = viewModel::onDarkModeToggled)
                }
            }
        }

        item {
            SettingsSection(title = "Wallpaper") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (currentWallpaper == null) "System wallpaper / live wallpaper is active" else "Custom wallpaper is active for ${currentProfile.name.replace('_', ' ')}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Choose image", modifier = Modifier.clickable { wallpaperLauncher.launch(arrayOf("image/*")) })
                        if (currentWallpaper != null) {
                            Text("Use system", modifier = Modifier.clickable { scope.launch { settingsRepository.setProfileWallpaper(currentProfile, null) } })
                        }
                    }
                    Text("Wallpaper is stored separately for each Scale UI profile. Android live/system wallpaper remains supported when no custom image is selected.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f))
                }
            }
        }

        item {
            SettingsSection(title = "Android Widgets") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Use real widgets from installed apps. Scale UI hosts them directly through Android's AppWidget system.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                    Text("+ Add system widget", modifier = Modifier.clickable {
                        val id = SystemWidgetHost.allocateId(context)
                        pendingWidgetId = id
                        widgetPickLauncher.launch(SystemWidgetHost.pickIntent(id))
                    })
                    val systemWidgets by settingsRepository.systemWidgets.collectAsState(initial = emptyList())
                    systemWidgets.forEach { widget ->
                        val info = SystemWidgetHost.info(context, widget.appWidgetId)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(info?.loadLabel(context.packageManager)?.toString() ?: widget.provider.substringAfterLast('/'), style = MaterialTheme.typography.bodyMedium)
                            Text("Remove", modifier = Modifier.clickable {
                                SystemWidgetHost.deleteId(context, widget.appWidgetId)
                                scope.launch { settingsRepository.removeSystemWidget(widget.appWidgetId) }
                            })
                        }
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Theme") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        ThemeMode.values().forEach { mode ->
                            ThemeSwatch(mode = mode, isSelected = mode == themeMode, onClick = { viewModel.onThemeModeSelected(mode) })
                        }
                    }
                    Text(
                        "Themes apply across Home, Zero Screen, App Drawer, Widgets and Settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f),
                    )
                    var showPreset by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
                    GlassSurface(
                        modifier = Modifier.fillMaxWidth().clickable { showPreset = true },
                        shape = RoundedCornerShape(24.dp),
                        alphaOverride = .26f,
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Pre-setup Home Screen", style = MaterialTheme.typography.titleSmall)
                            Text("Preview the locked reference layout before customizing your Home Screen.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                        }
                    }
                    if (showPreset) {
                        androidx.compose.material3.AlertDialog(
                            onDismissRequest = { showPreset = false },
                            title = { Text("Pre-setup Home • Preview") },
                            text = { PreSetupHomeScreen(apps = apps, modifier = Modifier.fillMaxWidth().height(500.dp)) },
                            confirmButton = { TextButton(onClick = { showPreset = false }) { Text("Done") } },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Home Screen — Icon Shape") {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    IconShape.values().forEach { shape ->
                        IconShapeSwatch(
                            shape = shape,
                            isSelected = shape == iconShape,
                            onClick = { viewModel.onIconShapeSelected(shape) },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Home Screen — Grid Size") {
                Column {
                    Text(
                        "Columns: ${gridConfig.columns}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Slider(
                        value = gridConfig.columns.toFloat(),
                        valueRange = 1f..10f,
                        steps = 8,
                        onValueChange = {
                            viewModel.onGridSizeChanged(it.toInt(), gridConfig.rows)
                        },
                    )
                    Text(
                        "Rows: ${gridConfig.rows}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Slider(
                        value = gridConfig.rows.toFloat(),
                        valueRange = 1f..10f,
                        steps = 8,
                        onValueChange = {
                            viewModel.onGridSizeChanged(gridConfig.columns, it.toInt())
                        },
                    )
                }
            }
        }

        item {
            SettingsSection(title = "Home Widgets") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    com.scaleui.launcher.widgets.ScaleWidgetType.values().forEach { type ->
                        val placement = homeWidgets.firstOrNull { it.type == type }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(type.name.replace('_', ' '))
                            if (placement == null) {
                                Text("Add", modifier = Modifier.clickable { viewModel.addWidget(type) })
                            } else {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    com.scaleui.launcher.widgets.WidgetSize.values().forEach { size ->
                                        Text(size.name.take(1), modifier = Modifier.clickable { viewModel.resizeWidget(type, size) })
                                    }
                                    Text("×", modifier = Modifier.clickable { viewModel.removeWidget(type) })
                                }
                            }
                        }
                    }
                    Text("Widgets appear above the app grid on Home. Long-press an app to move it.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            SettingsSection(title = "Profile") {
                Column {
                    Text("Active: ${currentProfile.name}", style = MaterialTheme.typography.bodyLarge)
                    val target = if (currentProfile == Profile.PROFILE_1) Profile.PROFILE_2 else Profile.PROFILE_1

                    if (!hasPinSet) {
                        Text("No PIN set — set one to protect profile switching:", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                        BasicTextField(
                            value = newPinInput,
                            onValueChange = { value -> if (value.length <= 12 && value.all(Char::isDigit)) newPinInput = value },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        )
                        Text(
                            "Save PIN",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(top = 8.dp).clickable {
                                if (newPinInput.length in 4..12) { profileManager.setPin(newPinInput); newPinInput = "" }
                            },
                        )
                        Text(
                            "Switch to $target (no PIN yet)",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(top = 12.dp).clickable { profileManager.switchProfileUnlocked(target) },
                        )
                    } else {
                        Text("Enter PIN to switch to $target:", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                        BasicTextField(
                            value = pinInput,
                            onValueChange = { value -> if (value.length <= 12 && value.all(Char::isDigit)) pinInput = value },
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        )
                        if (pinError) Text("Wrong PIN", color = Color.Red, style = MaterialTheme.typography.labelSmall)
                        Text(
                            "Switch",
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(top = 8.dp).clickable {
                                profileManager.attemptSwitchWithPin(target, pinInput)
                            },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Animation Performance") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AnimationMode.values().forEach { mode ->
                        Text(
                            text = mode.name.lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelLarge,
                            color = if (mode == animationMode) Color.White else Color.White.copy(alpha = 0.4f),
                            modifier = Modifier.clickable { viewModel.onAnimationModeSelected(mode) },
                        )
                    }
                }
            }
        }

        item {
            SettingsSection(title = "Gestures") {
                val gestureMap by viewModel.gestureMap.collectAsState()
                com.scaleui.launcher.special.GestureTrigger.values().forEach { trigger ->
                    val current = gestureMap[trigger] ?: com.scaleui.launcher.special.GestureAction.NONE
                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(trigger.name.replace('_', ' '), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            current.name.replace('_', ' '),
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.clickable {
                                val actions = com.scaleui.launcher.special.GestureAction.values()
                                val next = actions[(actions.indexOf(current) + 1) % actions.size]
                                viewModel.onGestureActionSelected(trigger, next)
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable () -> Unit) {
    GlassSurface(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 12.dp),
            )
            content()
        }
    }
}

@Composable
private fun ThemeSwatch(mode: ThemeMode, isSelected: Boolean, onClick: () -> Unit) {
    val config = ThemeEngine.configFor(mode)
    val shape = RoundedCornerShape(22.dp)
    val title = when (mode) {
        ThemeMode.FROST_GLASS -> "Frost Glass"
        ThemeMode.LIQUID_GLASS -> "Liquid Glass"
        ThemeMode.GLASS -> "Glass"
        ThemeMode.BLUR_MIST -> "Blur Mist"
        ThemeMode.CUSTOM -> "Custom"
    }
    val subtitle = when (mode) {
        ThemeMode.FROST_GLASS -> "Soft + bright"
        ThemeMode.LIQUID_GLASS -> "Clear + fluid"
        ThemeMode.GLASS -> "Deep + glossy"
        ThemeMode.BLUR_MIST -> "Misty + calm"
        ThemeMode.CUSTOM -> "Your style"
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(110.dp).clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .size(106.dp, 84.dp)
                .clip(shape)
                .background(
                    when (mode) {
                        ThemeMode.FROST_GLASS -> Brush.linearGradient(listOf(Color(0xFFEAF2FF), Color(0xFF8290A6), Color(0xFF343D4C)))
                        ThemeMode.LIQUID_GLASS -> Brush.linearGradient(listOf(Color(0xFFE8FBFF), Color(0xFF8DDDF2), Color(0xFF61758A)))
                        ThemeMode.GLASS -> Brush.linearGradient(listOf(Color(0xFF1BC8EF), Color(0xFF705CFF), Color(0xFFF3A82F)))
                        ThemeMode.BLUR_MIST -> Brush.radialGradient(listOf(Color(0xFF7A7480), Color(0xFF25252B), Color(0xFF101014)))
                        ThemeMode.CUSTOM -> Brush.linearGradient(listOf(Color(0xFF596273), Color(0xFF17191F)))
                    }
                )
                .border(
                    width = if (isSelected) 2.dp else .8.dp,
                    color = if (isSelected) config.accentColor.copy(alpha = .95f) else Color.White.copy(alpha = .18f),
                    shape = shape,
                ),
        ) {
            // Background “window” + mini cards make each swatch read like a tiny home screen.
            Box(
                Modifier
                    .fillMaxWidth(.76f)
                    .height(38.dp)
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(14.dp))
                    .background(config.backgroundTint.copy(alpha = (config.tintAlpha * 1.35f).coerceAtMost(.62f)))
                    .border(.8.dp, Color.White.copy(alpha = .28f), RoundedCornerShape(14.dp)),
            ) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                ) {
                    repeat(3) { index ->
                        Box(
                            Modifier
                                .size(11.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(config.accentColor.copy(alpha = .18f + index * .07f))
                                .border(.5.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(4.dp))
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.width(17.dp).height(4.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(.28f)))
                }
            }
            Box(
                Modifier
                    .width(34.dp)
                    .height(3.dp)
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 9.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.White.copy(.34f)),
            )
            if (isSelected) {
                Box(
                    Modifier
                        .size(22.dp)
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .clip(CircleShape)
                        .background(config.accentColor.copy(.94f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Check,
                        contentDescription = "Selected",
                        tint = Color.Black.copy(alpha = .72f),
                        modifier = Modifier.size(13.dp),
                    )
                }
            }
        }
        Text(title, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 7.dp), maxLines = 1)
        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .48f), maxLines = 1)
    }
}

@Composable
private fun IconShapeSwatch(shape: IconShape, isSelected: Boolean, onClick: () -> Unit) {
    val glass = com.scaleui.launcher.theme.LocalGlassConfig.current
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(shape.toComposeShape())
            .background(if (isSelected) glass.accentColor.copy(alpha = .92f) else Color.White.copy(alpha = 0.16f))
            .border(
                width = if (isSelected) 1.5.dp else .8.dp,
                color = if (isSelected) glass.accentColor.copy(alpha = .85f) else Color.White.copy(alpha = .20f),
                shape = shape.toComposeShape(),
            )
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .size(14.dp)
                .clip(shape.toComposeShape())
                .background(if (isSelected) Color.Black.copy(alpha = .14f) else Color.White.copy(alpha = .34f)),
        )
    }
}
