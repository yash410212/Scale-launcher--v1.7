package com.scaleui.launcher.profiles

import com.scaleui.launcher.core.apps.AppInfo

/** Shared by Home + Drawer so both apply the same profile-visibility + hidden-apps rules. */
fun filterForProfile(
    apps: List<AppInfo>,
    profile: Profile,
    visibilityMap: Map<String, AppVisibility>,
): List<AppInfo> = apps.filter { app ->
    val visibility = visibilityMap[app.packageName] ?: AppVisibility.BOTH
    visibility.isVisibleIn(profile)
}
