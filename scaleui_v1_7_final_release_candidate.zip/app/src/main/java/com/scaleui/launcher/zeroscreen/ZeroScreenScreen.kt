package com.scaleui.launcher.zeroscreen

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.widgets.clock.ClockWidget
import com.scaleui.launcher.core.widgets.SystemWidgetHost
import com.scaleui.launcher.theme.GlassSurface
import androidx.compose.foundation.layout.padding

/**
 * Spec section 2: dedicated Zero Screen — screen time, brief notes,
 * calendar, widgets (music). Reached via swipe-down on Home (Part 12).
 */
@Composable
fun ZeroScreenScreen(
    viewModel: ZeroScreenViewModel,
    onClose: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val note by viewModel.briefNote.collectAsState()
    val systemWidgets by viewModel.settingsRepository.systemWidgets.collectAsState(initial = emptyList())

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onHorizontalDrag = { change, amount -> drag += amount; change.consume() },
                    onDragEnd = { if (drag < -120f) onClose(); drag = 0f },
                    onDragCancel = { drag = 0f },
                )
            },
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { ClockWidget() }
        item { ScreenTimeCard() }
        item { BriefNotesWidget(text = note, onTextChange = viewModel::onNoteChange) }
        item { ZeroMusicWidget() }
        item { ZeroCalendarWidget() }
        systemWidgets.forEach { widget ->
            item {
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier.fillMaxSize().height((widget.heightCells.coerceIn(1, 6) * 56).dp),
                ) {
                    GlassSurface(
                        modifier = Modifier.fillMaxSize(),
                        alphaOverride = .16f,
                    ) {
                        SystemWidgetHost.View(widget.appWidgetId)
                    }
                }
            }
        }
    }
}
