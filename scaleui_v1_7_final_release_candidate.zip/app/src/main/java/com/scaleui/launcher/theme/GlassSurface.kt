package com.scaleui.launcher.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import com.scaleui.launcher.animation.LocalAnimationConfig
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Theme-wide glass surface.
 *
 * It intentionally keeps the content crisp. Android's regular Compose blur is
 * a foreground blur and would blur icons/text as well; this renderer instead
 * creates the glass illusion with low-overdraw optical layers and a refractive
 * edge. Real per-card backdrop blur can be added later without changing the
 * call sites.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(LocalGlassConfig.current.cornerRadius),
    alphaOverride: Float? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val config = LocalGlassConfig.current
    val animation = LocalAnimationConfig.current
    val alpha = (alphaOverride ?: config.tintAlpha).coerceIn(0f, 1f)
    val opticalEffects = animation.blurEnabled
    val elevation = when {
        !opticalEffects -> 2.dp
        config.hasRefractionEdge -> 7.dp
        config.hasSpecularHighlight -> 6.dp
        config.hasCornerHighlight -> 5.dp
        else -> 3.dp
    }

    Box(
        modifier = modifier
            .shadow(
                elevation = elevation,
                shape = shape,
                clip = false,
                ambientColor = Color.Black.copy(alpha = if (opticalEffects) config.shadowAlpha * 0.48f else config.shadowAlpha * 0.28f),
                spotColor = Color.Black.copy(alpha = if (opticalEffects) config.shadowAlpha * 0.78f else config.shadowAlpha * 0.30f),
            )
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        config.backgroundTint.copy(alpha = (alpha + config.surfaceGlowAlpha).coerceAtMost(1f)),
                        config.backgroundTint.copy(alpha = alpha),
                        config.backgroundTint.copy(alpha = (alpha * 0.88f).coerceAtLeast(0f)),
                    ),
                    start = Offset.Zero,
                    end = Offset(900f, 1400f),
                ),
                shape,
            )
            .drawWithCache {
                val outline = shape.createOutline(size, layoutDirection, this)
                val accentBrush = Brush.radialGradient(
                    colors = listOf(
                        config.accentColor.copy(alpha = config.accentSheenAlpha),
                        Color.Transparent,
                    ),
                    center = Offset(size.width * 0.16f, size.height * 0.08f),
                    radius = (size.maxDimension * 0.95f).coerceAtLeast(1f),
                )
                val topSheen = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (config.hasSpecularHighlight) 0.16f else 0.055f),
                        Color.Transparent,
                        Color.Transparent,
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(size.width * 0.92f, size.height * 0.72f),
                )
                val cornerGlow = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = 0.14f), Color.Transparent),
                    center = Offset(size.width * 0.12f, size.height * 0.08f),
                    radius = (size.minDimension * 1.55f).coerceAtLeast(1f),
                )
                val mist = Brush.radialGradient(
                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.20f)),
                    center = Offset(size.width * 0.5f, size.height * 0.42f),
                    radius = (size.maxDimension * 0.82f).coerceAtLeast(1f),
                )
                val lowerShade = Brush.verticalGradient(
                    colors = listOf(
                        Color.Transparent,
                        Color.Transparent,
                        Color.Black.copy(alpha = 0.055f),
                    ),
                    startY = size.height * 0.42f,
                    endY = size.height,
                )
                val refraction = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.50f),
                        Color.White.copy(alpha = 0.10f),
                        Color.Transparent,
                        Color.White.copy(alpha = 0.16f),
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, size.height),
                )
                onDrawWithContent {
                    // Optical layers are drawn behind content so text/icons stay crisp.
                    drawRect(accentBrush)
                    if (opticalEffects && config.hasSpecularHighlight) drawRect(topSheen)
                    if (opticalEffects && config.hasCornerHighlight) drawRect(cornerGlow)
                    if (opticalEffects && config.hasRefractionEdge) {
                        drawRect(
                            Brush.linearGradient(
                                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.035f), Color.Transparent),
                                start = Offset(0f, size.height * 0.28f),
                                end = Offset(size.width, size.height * 0.70f),
                            )
                        )
                    }
                    if (opticalEffects && config.hasMistVignette) drawRect(mist)
                    if (opticalEffects) drawRect(lowerShade)
                    drawContent()

                    // One clean outline is cheaper and visually calmer than stacking borders.
                    when {
                        opticalEffects && config.hasRefractionEdge -> drawOutline(
                            outline = outline,
                            brush = refraction,
                            style = Stroke(width = 1.35.dp.toPx()),
                        )
                        config.borderWidth > Dp.Hairline -> drawOutline(
                            outline = outline,
                            color = config.borderColor,
                            style = Stroke(width = config.borderWidth.toPx()),
                        )
                    }
                    if (config.innerHighlightAlpha > 0f) {
                        drawOutline(
                            outline = outline,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = config.innerHighlightAlpha),
                                    Color.Transparent,
                                ),
                                start = Offset.Zero,
                                end = Offset(size.width, size.height),
                            ),
                            style = Stroke(width = 0.9.dp.toPx()),
                        )
                    }
                }
            },
    ) {
        content()
    }
}
