package com.scaleui.launcher.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Resolves [ThemeMode] -> [GlassConfig].
 *
 * Part 6 scope: skeleton values that make all 4 themes visually distinct
 * and roughly match their reference images. Parts 7-10 each take one
 * theme and refine its exact tokens (precise colors, blur behavior on
 * different backgrounds, etc.) — this function is the one place those
 * refinements land; nothing else changes.
 */
object ThemeEngine {

    fun configFor(mode: ThemeMode, custom: CustomThemeConfig = CustomThemeConfig()): GlassConfig =
        when (mode) {
            ThemeMode.FROST_GLASS -> GlassConfig(
                backgroundTint = Color.White,
                tintAlpha = 0.135f,
                blurRadius = 7.dp,       // soft glow blur, per the "Frosted" reference
                borderColor = Color.White.copy(alpha = 0.44f),
                borderWidth = 1.dp,
                cornerRadius = 27.dp,
                surfaceGlowAlpha = 0.016f,
                innerHighlightAlpha = 0.070f,
                iconSlotAlpha = 0.075f,
                iconSlotBorderAlpha = 0.24f,
                iconSlotShadowAlpha = 0.10f,
                accentColor = Color(0xFFEAF2FF),
                shadowAlpha = 0.125f,
                accentSheenAlpha = 0.028f,
            )

            ThemeMode.LIQUID_GLASS -> GlassConfig(
                backgroundTint = Color.White,
                tintAlpha = 0.040f,       // clearer, thinner iOS-style glass over the wallpaper
                blurRadius = 2.dp,
                borderColor = Color.White.copy(alpha = 0.62f),
                borderWidth = 1.0.dp,
                cornerRadius = 28.dp,
                hasSpecularHighlight = true,
                hasRefractionEdge = true,
                surfaceGlowAlpha = 0.022f,
                innerHighlightAlpha = 0.105f,
                iconSlotAlpha = 0.095f,
                iconSlotBorderAlpha = 0.34f,
                iconSlotShadowAlpha = 0.16f,
                accentColor = Color(0xFFDFF8FF),
                shadowAlpha = 0.115f,
                accentSheenAlpha = 0.034f,
            )

            ThemeMode.GLASS -> GlassConfig(
                backgroundTint = Color(0xFF17171C),
                tintAlpha = 0.275f,        // colorful bleed-through cards + component sheet reference
                blurRadius = 5.dp,
                borderColor = Color.White.copy(alpha = 0.28f),
                borderWidth = 1.dp,
                cornerRadius = 24.dp,
                hasCornerHighlight = true,
                surfaceGlowAlpha = 0.024f,
                innerHighlightAlpha = 0.085f,
                accentColor = Color(0xFFB9D9FF),
                shadowAlpha = 0.20f,
                accentSheenAlpha = 0.038f,
            )

            ThemeMode.BLUR_MIST -> GlassConfig(
                backgroundTint = Color(0xFF0A0A0C),
                tintAlpha = 0.46f,        // heavy bokeh blur, per the "Blur/One UI" reference
                blurRadius = 9.dp,
                borderColor = Color.Transparent,
                borderWidth = 0.dp,
                cornerRadius = 28.dp,
                hasMistVignette = true,
                surfaceGlowAlpha = 0.015f,
                innerHighlightAlpha = 0.035f,
                accentColor = Color(0xFFD8D2E8),
                shadowAlpha = 0.22f,
                accentSheenAlpha = 0.018f,
            )

            ThemeMode.CUSTOM -> GlassConfig(
                backgroundTint = custom.backgroundTint,
                tintAlpha = custom.transparency,
                blurRadius = custom.blurRadius,
                borderColor = custom.borderColor.copy(alpha = 0.3f),
                borderWidth = 1.dp,
                cornerRadius = custom.cornerRadius,
                accentColor = custom.borderColor,
                shadowAlpha = 0.20f,
                accentSheenAlpha = 0.035f,
            )
        }
}
