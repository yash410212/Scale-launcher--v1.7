package com.scaleui.launcher.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.remember
import com.scaleui.launcher.animation.AnimationMode
import com.scaleui.launcher.animation.LocalAnimationConfig
import com.scaleui.launcher.animation.toConfig

/** Read anywhere below ScaleTheme with `LocalGlassConfig.current`. */
val LocalGlassConfig = compositionLocalOf { GlassConfig.Fallback }

/** Read anywhere below ScaleTheme with `LocalThemeMode.current` — for the rare
 *  case a composable needs to branch on the mode itself, not just its tokens
 *  (e.g. a theme picker highlighting the active option in Settings). */
val LocalThemeMode = compositionLocalOf { ThemeMode.GLASS }

/**
 * Wraps launcher content, resolving [themeMode] to a [GlassConfig] via
 * ThemeEngine and providing it — plus [themeMode] itself and [iconShape] —
 * through CompositionLocals so every screen (Home, Drawer, Zero Screen,
 * Settings, widgets) picks up the active theme/shape automatically — no
 * screen needs those as explicit parameters of its own.
 *
 * Part 11: [themeMode], [isDarkMode], and [iconShape] are now driven by
 * SettingsViewModel (backed by DataStore) instead of MainActivity's
 * temporary dev switcher — that switcher and its local state are removed
 * this part. [isDarkMode] is spec's separate General > Dark/Light Theme
 * toggle — it picks MaterialTheme's base color scheme, independent of
 * which of the 4 glass ThemeModes is active.
 */
@Composable
fun ScaleTheme(
    themeMode: ThemeMode = ThemeMode.GLASS,
    isDarkMode: Boolean = true,
    iconShape: IconShape = IconShape.CIRCLE,
    animationMode: AnimationMode = AnimationMode.BALANCED,
    customConfig: CustomThemeConfig = CustomThemeConfig(),
    content: @Composable () -> Unit,
) {
    val glassConfig = remember(themeMode, customConfig) {
        ThemeEngine.configFor(themeMode, customConfig)
    }
    val animationConfig = remember(animationMode) { animationMode.toConfig() }

    CompositionLocalProvider(
        LocalGlassConfig provides glassConfig,
        LocalThemeMode provides themeMode,
        LocalIconShape provides iconShape,
        LocalAnimationConfig provides animationConfig,
    ) {
        MaterialTheme(
            colorScheme = if (isDarkMode) {
                darkColorScheme(
                    primary = glassConfig.accentColor,
                    onPrimary = Color.Black,
                    secondary = glassConfig.accentColor,
                    tertiary = glassConfig.accentColor,
                    background = Color.Transparent,
                    surface = Color.Transparent,
                    onSurface = Color.White,
                    onBackground = Color.White,
                )
            } else {
                lightColorScheme(
                    primary = Color(0xFF355B7A),
                    secondary = Color(0xFF4F6F84),
                    tertiary = Color(0xFF5E6170),
                    background = Color.Transparent,
                    surface = Color.Transparent,
                    onSurface = Color(0xFF15171B),
                    onBackground = Color(0xFF15171B),
                )
            },
            content = content,
        )
    }
}
