package com.scaleui.launcher.home.model

import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.folders.ScaleFolder

data class HomeGridConfig(val columns: Int = 5, val rows: Int = 6)

/** Part 12: a home cell holds either a bare app or a folder — same grid, two content types. */
sealed class HomeCellItem {
    data class AppItem(val app: AppInfo) : HomeCellItem()
    data class FolderItem(val folder: ScaleFolder) : HomeCellItem()
}

data class HomeIconPlacement(val item: HomeCellItem, val row: Int, val col: Int)

data class HomeLayoutState(
    val gridConfig: HomeGridConfig = HomeGridConfig(),
    val placements: List<HomeIconPlacement> = emptyList(),
)
