package com.scaleui.launcher.core.widgets

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView

/** Real Android AppWidget host used by Scale UI Home/Zero Screen. */
object SystemWidgetHost {
    private const val HOST_ID = 0x5343414C
    private var host: AppWidgetHost? = null
    private var manager: AppWidgetManager? = null
    private var listening = false

    fun init(context: Context) {
        val appContext = context.applicationContext
        if (host == null) {
            manager = AppWidgetManager.getInstance(appContext)
            host = AppWidgetHost(appContext, HOST_ID)
        }
        if (!listening) {
            host?.startListening()
            listening = true
        }
    }

    fun start(context: Context) { init(context) }

    fun stop() {
        if (listening) host?.stopListening()
        listening = false
    }

    fun allocateId(context: Context): Int {
        init(context)
        return host?.allocateAppWidgetId() ?: error("AppWidgetHost is not initialized")
    }

    fun deleteId(context: Context, id: Int) {
        // Deleting an ID does not require the listener to be started.
        runCatching { host?.deleteAppWidgetId(id) }
    }

    fun info(context: Context, id: Int): AppWidgetProviderInfo? {
        init(context)
        return runCatching { manager?.getAppWidgetInfo(id) }.getOrNull()
    }

    fun installedProviders(context: Context): List<AppWidgetProviderInfo> {
        init(context)
        return manager?.installedProviders
            ?.sortedBy { it.loadLabel(context.packageManager).toString().lowercase() }
            ?: emptyList()
    }

    fun bindIntent(appWidgetId: Int, provider: ComponentName): Intent =
        Intent(AppWidgetManager.ACTION_APPWIDGET_BIND).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, provider)
        }

    fun pickIntent(appWidgetId: Int): Intent =
        Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId)
        }

    @Composable
    fun View(appWidgetId: Int, modifier: Modifier = Modifier) {
        val context = LocalContext.current
        AndroidView(
            modifier = modifier.fillMaxSize(),
            factory = {
                init(context)
                val widgetInfo = info(context, appWidgetId)
                val widgetHost = host
                if (widgetInfo != null && widgetHost != null) {
                    runCatching { widgetHost.createView(context, appWidgetId, widgetInfo) }.getOrElse {
                        unavailableView(context)
                    }
                } else {
                    unavailableView(context)
                }
            },
        )
    }

    private fun unavailableView(context: Context): FrameLayout = FrameLayout(context).apply {
        setBackgroundColor(0x12000000)
        val message = TextView(context).apply {
            text = "Widget unavailable"
            setTextColor(0xBFFFFFFF.toInt())
            gravity = Gravity.CENTER
            textSize = 12f
        }
        addView(message, FrameLayout.LayoutParams(-1, -1))
    }
}

data class SystemWidgetPlacement(
    val appWidgetId: Int,
    val provider: String,
    val widthCells: Int = 4,
    val heightCells: Int = 2,
)
