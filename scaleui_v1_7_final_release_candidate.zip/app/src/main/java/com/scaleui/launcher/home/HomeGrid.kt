package com.scaleui.launcher.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.folders.FolderPreview
import com.scaleui.launcher.folders.ScaleFolder
import com.scaleui.launcher.home.model.HomeCellItem
import com.scaleui.launcher.home.model.HomeLayoutState
import kotlin.math.sqrt

/** Fixed grid with long-press drag-and-drop app reordering. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeGrid(
    layout: HomeLayoutState,
    onAppClick: (AppInfo) -> Unit,
    onFolderClick: (ScaleFolder) -> Unit,
    onMoveApp: (fromPackage: String, toPackage: String) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier,
) {
    val placementByCell = remember(layout) { layout.placements.associateBy { it.row to it.col } }
    val cellBounds = remember(layout) { mutableStateMapOf<Pair<Int, Int>, Pair<Offset, Offset>>() }
    val columns = layout.gridConfig.columns.coerceAtLeast(1)
    val rows = layout.gridConfig.rows.coerceAtLeast(1)

    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        for (row in 0 until rows) {
            Row(modifier = Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (col in 0 until columns) {
                    val item = placementByCell[row to col]?.item
                    val dragDelta = remember { mutableStateOf(Offset.Zero) }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(4.dp)
                            .onGloballyPositioned { coordinates ->
                                cellBounds[row to col] = coordinates.positionInRoot() to Offset(coordinates.size.width.toFloat(), coordinates.size.height.toFloat())
                            }
                            .then(
                                if (item is HomeCellItem.AppItem) {
                                    Modifier.pointerInput(item.app.packageName, layout) {
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = { dragDelta.value = Offset.Zero },
                                            onDrag = { change, amount ->
                                                dragDelta.value += amount
                                                change.consume()
                                            },
                                            onDragEnd = {
                                                val origin = cellBounds[row to col]?.first ?: return@detectDragGesturesAfterLongPress
                                                val center = origin + (cellBounds[row to col]?.second ?: Offset.Zero) / 2f + dragDelta.value
                                                val target = cellBounds.entries.minByOrNull { (_, bounds) ->
                                                    val targetCenter = bounds.first + bounds.second / 2f
                                                    val dx = targetCenter.x - center.x
                                                    val dy = targetCenter.y - center.y
                                                    sqrt(dx * dx + dy * dy)
                                                }?.key
                                                val targetItem = target?.let { placementByCell[it]?.item }
                                                if (targetItem is HomeCellItem.AppItem) {
                                                    onMoveApp(item.app.packageName, targetItem.app.packageName)
                                                }
                                            },
                                            onDragCancel = { dragDelta.value = Offset.Zero },
                                        )
                                    }
                                } else Modifier
                            ),
                    ) {
                        when (item) {
                            is HomeCellItem.AppItem -> HomeIcon(app = item.app, onClick = onAppClick)
                            is HomeCellItem.FolderItem -> FolderPreview(folder = item.folder, onClick = { onFolderClick(item.folder) })
                            null -> Unit
                        }
                    }
                }
            }
        }
    }
}
