package com.scaleui.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.scaleui.launcher.home.model.HomeGridConfig
import com.scaleui.launcher.theme.IconShape
import com.scaleui.launcher.theme.ThemeMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "scale_ui_settings")

/**
 * Persisted settings, spec section 5 (Settings screen). This is the ONE
 * place General + Home Screen Controls values are read from/written to —
 * everything else (ScaleTheme, HomePagerViewModel, DrawerIcon/HomeIcon via
 * LocalIconShape) just observes the StateFlows this class derives from
 * DataStore, so it never touches Preferences directly.
 *
 * Home widget placement and drawer controls are persisted here alongside the rest of launcher settings.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val IS_DARK_MODE = booleanPreferencesKey("is_dark_mode")
        val ICON_SHAPE = stringPreferencesKey("icon_shape")
        val GRID_COLUMNS = intPreferencesKey("grid_columns")
        val GRID_ROWS = intPreferencesKey("grid_rows")
        val BRIEF_NOTE = stringPreferencesKey("brief_note")
        val CURRENT_PROFILE = stringPreferencesKey("current_profile")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val APP_VISIBILITY_MAP = stringPreferencesKey("app_visibility_map") // "pkg=VALUE,pkg=VALUE,..."
        val FROZEN_APPS = stringPreferencesKey("frozen_apps") // "pkg,pkg,pkg"
        val ANIMATION_MODE = stringPreferencesKey("animation_mode")
        val GESTURE_MAP = stringPreferencesKey("gesture_map") // "TRIGGER=ACTION,..."
        val HOME_ORDER = stringPreferencesKey("home_order") // "pkg,pkg,pkg,..."
        val HOME_WIDGETS = stringPreferencesKey("home_widgets") // "TYPE:SIZE,TYPE:SIZE,..."
        val SYSTEM_WIDGETS = stringPreferencesKey("system_widgets") // "id|provider|width|height,..."
        val PROFILE_WALLPAPERS = stringPreferencesKey("profile_wallpapers") // "PROFILE_1=uri,PROFILE_2=uri"
    }

    val gestureMap = context.settingsDataStore.data.map { prefs ->
        val stored = (prefs[Keys.GESTURE_MAP] ?: "")
            .split(",")
            .mapNotNull { entry ->
                val parts = entry.split("=")
                if (parts.size != 2) return@mapNotNull null
                val trigger = runCatching { com.scaleui.launcher.special.GestureTrigger.valueOf(parts[0]) }.getOrNull() ?: return@mapNotNull null
                val action = runCatching { com.scaleui.launcher.special.GestureAction.valueOf(parts[1]) }.getOrNull() ?: return@mapNotNull null
                trigger to action
            }.toMap()
        com.scaleui.launcher.special.DEFAULT_GESTURE_MAP + stored
    }

    suspend fun setGestureAction(trigger: com.scaleui.launcher.special.GestureTrigger, action: com.scaleui.launcher.special.GestureAction) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.GESTURE_MAP] ?: "")
                .split(",").filter { it.isNotBlank() && !it.startsWith("${trigger.name}=") }
            prefs[Keys.GESTURE_MAP] = (current + "${trigger.name}=${action.name}").joinToString(",")
        }
    }


    val homeWidgets = context.settingsDataStore.data.map { prefs ->
        (prefs[Keys.HOME_WIDGETS] ?: "").split(",").mapNotNull { entry ->
            val parts = entry.split(":")
            if (parts.size != 2) return@mapNotNull null
            val type = runCatching { com.scaleui.launcher.widgets.ScaleWidgetType.valueOf(parts[0]) }.getOrNull() ?: return@mapNotNull null
            val size = runCatching { com.scaleui.launcher.widgets.WidgetSize.valueOf(parts[1]) }.getOrNull() ?: com.scaleui.launcher.widgets.WidgetSize.MEDIUM
            com.scaleui.launcher.widgets.WidgetPlacement(type, size)
        }
    }

    suspend fun addHomeWidget(type: com.scaleui.launcher.widgets.ScaleWidgetType) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.HOME_WIDGETS] ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
            if (current.none { it.startsWith("${type.name}:") }) current += "${type.name}=MEDIUM".replace('=', ':')
            prefs[Keys.HOME_WIDGETS] = current.joinToString(",")
        }
    }

    suspend fun removeHomeWidget(type: com.scaleui.launcher.widgets.ScaleWidgetType) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.HOME_WIDGETS] = (prefs[Keys.HOME_WIDGETS] ?: "").split(",").filter { it.isNotBlank() && !it.startsWith("${type.name}:") }.joinToString(",")
        }
    }

    suspend fun resizeHomeWidget(type: com.scaleui.launcher.widgets.ScaleWidgetType, size: com.scaleui.launcher.widgets.WidgetSize) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.HOME_WIDGETS] ?: "").split(",").filter { it.isNotBlank() && !it.startsWith("${type.name}:") }.toMutableList()
            current += "${type.name}:${size.name}"
            prefs[Keys.HOME_WIDGETS] = current.joinToString(",")
        }
    }


    val systemWidgets = context.settingsDataStore.data.map { prefs ->
        (prefs[Keys.SYSTEM_WIDGETS] ?: "").split(",").mapNotNull { entry ->
            val parts = entry.split("|")
            if (parts.size < 2) return@mapNotNull null
            val id = parts[0].toIntOrNull() ?: return@mapNotNull null
            val width = parts.getOrNull(2)?.toIntOrNull() ?: 4
            val height = parts.getOrNull(3)?.toIntOrNull() ?: 2
            com.scaleui.launcher.core.widgets.SystemWidgetPlacement(id, parts[1], width, height)
        }
    }

    suspend fun addSystemWidget(placement: com.scaleui.launcher.core.widgets.SystemWidgetPlacement) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.SYSTEM_WIDGETS] ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
            current.removeAll { it.startsWith("${placement.appWidgetId}|") }
            current += "${placement.appWidgetId}|${placement.provider}|${placement.widthCells}|${placement.heightCells}"
            prefs[Keys.SYSTEM_WIDGETS] = current.joinToString(",")
        }
    }

    suspend fun removeSystemWidget(appWidgetId: Int) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.SYSTEM_WIDGETS] = (prefs[Keys.SYSTEM_WIDGETS] ?: "").split(",")
                .filter { it.isNotBlank() && !it.startsWith("$appWidgetId|") }.joinToString(",")
        }
    }

    suspend fun resizeSystemWidget(appWidgetId: Int, width: Int, height: Int) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.SYSTEM_WIDGETS] ?: "").split(",").filter { it.isNotBlank() }.toMutableList()
            val index = current.indexOfFirst { it.startsWith("$appWidgetId|") }
            if (index >= 0) {
                val parts = current[index].split("|")
                val provider = parts.getOrNull(1) ?: return@edit
                current[index] = "$appWidgetId|$provider|${width.coerceIn(1,10)}|${height.coerceIn(1,10)}"
            }
            prefs[Keys.SYSTEM_WIDGETS] = current.joinToString(",")
        }
    }

    fun profileWallpaper(profile: com.scaleui.launcher.profiles.Profile) = context.settingsDataStore.data.map { prefs ->
        (prefs[Keys.PROFILE_WALLPAPERS] ?: "").split(",").mapNotNull { entry ->
            val parts = entry.split("=", limit = 2)
            if (parts.size == 2 && parts[0] == profile.name) parts[1] else null
        }.firstOrNull()
    }

    suspend fun setProfileWallpaper(profile: com.scaleui.launcher.profiles.Profile, uri: String?) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.PROFILE_WALLPAPERS] ?: "").split(",")
                .filter { it.isNotBlank() && !it.startsWith("${profile.name}=") }.toMutableList()
            if (!uri.isNullOrBlank()) current += "${profile.name}=$uri"
            prefs[Keys.PROFILE_WALLPAPERS] = current.joinToString(",")
        }
    }

    val homeOrder = context.settingsDataStore.data.map { prefs ->
        (prefs[Keys.HOME_ORDER] ?: "").split(",").filter { it.isNotBlank() }
    }

    suspend fun setHomeOrder(order: List<String>) {
        context.settingsDataStore.edit { prefs ->
            prefs[Keys.HOME_ORDER] = order.distinct().joinToString(",")
        }
    }

    val frozenApps = context.settingsDataStore.data.map { prefs ->
        (prefs[Keys.FROZEN_APPS] ?: "").split(",").filter { it.isNotBlank() }.toSet()
    }

    suspend fun toggleFrozen(packageName: String) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.FROZEN_APPS] ?: "").split(",").filter { it.isNotBlank() }.toMutableSet()
            if (!current.add(packageName)) current.remove(packageName)
            prefs[Keys.FROZEN_APPS] = current.joinToString(",")
        }
    }

    val animationMode = context.settingsDataStore.data.map { prefs ->
        prefs[Keys.ANIMATION_MODE]?.let {
            runCatching { com.scaleui.launcher.animation.AnimationMode.valueOf(it) }.getOrNull()
        } ?: com.scaleui.launcher.animation.AnimationMode.BALANCED
    }

    suspend fun setAnimationMode(mode: com.scaleui.launcher.animation.AnimationMode) {
        context.settingsDataStore.edit { it[Keys.ANIMATION_MODE] = mode.name }
    }

    /** Apps not in the map default to BOTH (visible everywhere) — only exceptions are stored. */
    val appVisibilityMap = context.settingsDataStore.data.map { prefs ->
        (prefs[Keys.APP_VISIBILITY_MAP] ?: "")
            .split(",")
            .mapNotNull { entry ->
                val parts = entry.split("=")
                if (parts.size != 2) return@mapNotNull null
                val visibility = runCatching {
                    com.scaleui.launcher.profiles.AppVisibility.valueOf(parts[1])
                }.getOrNull() ?: return@mapNotNull null
                parts[0] to visibility
            }
            .toMap()
    }

    suspend fun setAppVisibility(packageName: String, visibility: com.scaleui.launcher.profiles.AppVisibility) {
        context.settingsDataStore.edit { prefs ->
            val current = (prefs[Keys.APP_VISIBILITY_MAP] ?: "")
                .split(",").filter { it.isNotBlank() && !it.startsWith("$packageName=") }
            prefs[Keys.APP_VISIBILITY_MAP] = (current + "$packageName=${visibility.name}").joinToString(",")
        }
    }

    val briefNote = context.settingsDataStore.data.map { it[Keys.BRIEF_NOTE] ?: "" }

    suspend fun setBriefNote(text: String) {
        context.settingsDataStore.edit { it[Keys.BRIEF_NOTE] = text }
    }

    val currentProfile = context.settingsDataStore.data.map { prefs ->
        prefs[Keys.CURRENT_PROFILE]?.let {
            runCatching { com.scaleui.launcher.profiles.Profile.valueOf(it) }.getOrNull()
        } ?: com.scaleui.launcher.profiles.Profile.PROFILE_1
    }

    val hasPinSet = context.settingsDataStore.data.map { it[Keys.PIN_HASH] != null }

    suspend fun setCurrentProfile(profile: com.scaleui.launcher.profiles.Profile) {
        context.settingsDataStore.edit { it[Keys.CURRENT_PROFILE] = profile.name }
    }

    suspend fun setPin(pin: String) {
        require(pin.length in 4..12 && pin.all(Char::isDigit)) { "PIN must contain 4-12 digits" }
        context.settingsDataStore.edit { it[Keys.PIN_HASH] = hashPin(pin) }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val storedHash = context.settingsDataStore.data.map { it[Keys.PIN_HASH] }.first() ?: return false
        if (storedHash.startsWith("v2$")) return verifyV2(pin, storedHash)

        // One-time migration for the older unsalted SHA-256 format.
        val legacyDigest = java.security.MessageDigest.getInstance("SHA-256")
            .digest(pin.toByteArray(Charsets.UTF_8))
        val legacy = legacyDigest.joinToString("") { "%02x".format(it) }
        val valid = storedHash.length == 64 && storedHash.equals(legacy, ignoreCase = true)
        if (valid) {
            context.settingsDataStore.edit { it[Keys.PIN_HASH] = hashPin(pin) }
        }
        return valid
    }

    private fun hashPin(pin: String): String {
        val salt = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        val hash = pbkdf2(pin, salt)
        return "v2$" + java.util.Base64.getEncoder().encodeToString(salt) + "$" +
            java.util.Base64.getEncoder().encodeToString(hash)
    }

    private fun verifyV2(pin: String, stored: String): Boolean {
        val parts = stored.split('$')
        if (parts.size != 3 || parts[0] != "v2") return false
        return try {
            val salt = java.util.Base64.getDecoder().decode(parts[1])
            val expected = java.util.Base64.getDecoder().decode(parts[2])
            val actual = pbkdf2(pin, salt)
            java.security.MessageDigest.isEqual(actual, expected)
        } catch (_: IllegalArgumentException) { false }
    }

    private fun pbkdf2(pin: String, salt: ByteArray): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return try {
            javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    val themeMode = context.settingsDataStore.data.map { prefs ->
        prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() } ?: ThemeMode.GLASS
    }

    val isDarkMode = context.settingsDataStore.data.map { prefs ->
        prefs[Keys.IS_DARK_MODE] ?: true // launcher UIs default to dark
    }

    val iconShape = context.settingsDataStore.data.map { prefs ->
        prefs[Keys.ICON_SHAPE]?.let { runCatching { IconShape.valueOf(it) }.getOrNull() } ?: IconShape.CIRCLE
    }

    val homeGridConfig = context.settingsDataStore.data.map { prefs ->
        HomeGridConfig(
            columns = (prefs[Keys.GRID_COLUMNS] ?: 5).coerceIn(1, 10),
            rows = (prefs[Keys.GRID_ROWS] ?: 6).coerceIn(1, 10),
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setDarkMode(isDark: Boolean) {
        context.settingsDataStore.edit { it[Keys.IS_DARK_MODE] = isDark }
    }

    suspend fun setIconShape(shape: IconShape) {
        context.settingsDataStore.edit { it[Keys.ICON_SHAPE] = shape.name }
    }

    suspend fun setGridSize(columns: Int, rows: Int) {
        context.settingsDataStore.edit {
            it[Keys.GRID_COLUMNS] = columns.coerceIn(1, 10)
            it[Keys.GRID_ROWS] = rows.coerceIn(1, 10)
        }
    }
}
