package com.scaleui.launcher.home

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.folders.ScaleFolder
import com.scaleui.launcher.home.model.HomeLayoutState
import com.scaleui.launcher.widgets.ScaleWidgetCard
import com.scaleui.launcher.widgets.WidgetPlacement
import com.scaleui.launcher.core.widgets.SystemWidgetPlacement
import com.scaleui.launcher.core.widgets.SystemWidgetHost
import com.scaleui.launcher.theme.GlassSurface
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomePager(
    pages: List<HomeLayoutState>,
    onAppClick: (AppInfo) -> Unit,
    onFolderClick: (ScaleFolder) -> Unit,
    onMoveApp: (String, String) -> Unit = { _, _ -> },
    homeWidgets: List<WidgetPlacement> = emptyList(),
    systemWidgets: List<SystemWidgetPlacement> = emptyList(),
    onSwipeRight: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val pagerState = rememberPagerState(pageCount = { pages.size.coerceAtLeast(1) })
    val scope = rememberCoroutineScope()
    Column(modifier = modifier.fillMaxSize()) {
        if (homeWidgets.isNotEmpty() || systemWidgets.isNotEmpty()) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                homeWidgets.forEach { placement ->
                    ScaleWidgetCard(placement = placement, showControls = false)
                }
                systemWidgets.forEach { placement ->
                    GlassSurface(
                        modifier = Modifier.fillMaxWidth().height((placement.heightCells.coerceIn(1, 6) * 56).dp),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
                        alphaOverride = .14f,
                    ) {
                        SystemWidgetHost.View(
                            appWidgetId = placement.appWidgetId,
                            modifier = Modifier.fillMaxSize().padding(4.dp),
                        )
                    }
                }
            }
        }
        HorizontalPager(
            state = pagerState,
            userScrollEnabled = false,
            modifier = Modifier.weight(1f).fillMaxSize().pointerInput(pages.size) {
                var drag = 0f
                detectHorizontalDragGestures(
                    onDragStart = { drag = 0f },
                    onHorizontalDrag = { change, amount -> drag += amount; change.consume() },
                    onDragEnd = {
                        if (drag > 90f) {
                            if (pagerState.currentPage == 0) onSwipeRight()
                            else scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) }
                        } else if (drag < -90f && pagerState.currentPage < (pages.size - 1)) {
                            scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                        }
                    },
                    onDragCancel = { drag = 0f },
                )
            },
        ) { pageIndex ->
            if (pageIndex < pages.size) {
                HomeGrid(layout = pages[pageIndex], onAppClick = onAppClick, onFolderClick = onFolderClick, onMoveApp = onMoveApp)
            }
        }
        if (pages.size > 1) {
            PageIndicator(pageCount = pages.size, currentPage = pagerState.currentPage, modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp))
        }
    }
}

@Composable
private fun PageIndicator(pageCount: Int, currentPage: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally)) {
        repeat(pageCount) { index ->
            val active = index == currentPage
            Box(modifier = Modifier.size(if (active) 6.dp else 4.dp).clip(CircleShape).background(
                if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
            ))
        }
    }
}
