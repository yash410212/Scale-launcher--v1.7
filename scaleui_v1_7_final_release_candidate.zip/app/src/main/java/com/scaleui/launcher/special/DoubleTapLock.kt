package com.scaleui.launcher.special

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.scaleui.launcher.core.admin.ScaleDeviceAdminReceiver

/** Double-Tap-to-Lock (spec section 7). No-ops if Device Admin isn't granted yet. */
object DoubleTapLock {

    private fun adminComponent(context: Context) = ComponentName(context, ScaleDeviceAdminReceiver::class.java)

    fun isAdminActive(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent(context))
    }

    fun requestAdminActivation(context: Context) {
        val intent = Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent(context))
            putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Needed for Double-Tap-to-Lock")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun lockNow(context: Context) {
        if (!isAdminActive(context)) {
            requestAdminActivation(context)
            return
        }
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        runCatching { dpm.lockNow() }
    }
}
