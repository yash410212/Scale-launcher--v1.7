package com.scaleui.launcher.core.wallpaper

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import kotlin.math.max

/**
 * Profile wallpaper layer.
 *
 * A null URI intentionally leaves the Activity transparent so Android's real
 * system/live wallpaper remains visible. Custom images are decoded with
 * sampling to avoid loading a full-resolution camera photo into a low-RAM
 * launcher process.
 */
@Composable
fun LauncherWallpaper(uri: String?, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val configuration = LocalConfiguration.current
    val targetWidth = (configuration.screenWidthDp * configuration.densityDpi / 160f).toInt().coerceAtLeast(720)
    val targetHeight = (configuration.screenHeightDp * configuration.densityDpi / 160f).toInt().coerceAtLeast(1280)
    var bitmap by remember(uri, targetWidth, targetHeight) { mutableStateOf<android.graphics.Bitmap?>(null) }

    LaunchedEffect(uri, targetWidth, targetHeight) {
        bitmap = if (uri.isNullOrBlank()) {
            null
        } else {
            runCatching {
                val parsed = Uri.parse(uri)
                context.contentResolver.openInputStream(parsed)?.use { stream ->
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    stream.mark(64 * 1024)
                    BitmapFactory.decodeStream(stream, null, bounds)

                    val sourceW = bounds.outWidth.coerceAtLeast(1)
                    val sourceH = bounds.outHeight.coerceAtLeast(1)
                    val scale = max(
                        sourceW.toFloat() / targetWidth,
                        sourceH.toFloat() / targetHeight,
                    )
                    val sample = if (scale <= 1f) 1 else 2.let { base ->
                        var s = 1
                        while (s * base <= scale) s *= base
                        s
                    }

                    // Re-open because many ContentResolver streams do not support rewind.
                    context.contentResolver.openInputStream(parsed)?.use { decodeStream ->
                        BitmapFactory.Options().apply {
                            inSampleSize = sample.coerceAtLeast(1)
                            inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                        }.let { opts -> BitmapFactory.decodeStream(decodeStream, null, opts) }
                    }
                }
            }.getOrNull()
        }
    }

    Box(modifier = modifier.fillMaxSize().background(Color.Transparent)) {
        bitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
    }
}
