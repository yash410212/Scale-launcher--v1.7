package com.scaleui.launcher.profiles

/** Per-app visibility choice across the 2 profiles (spec section 6). */
enum class AppVisibility { PROFILE_1_ONLY, PROFILE_2_ONLY, BOTH, HIDDEN }

fun AppVisibility.isVisibleIn(profile: Profile): Boolean = when (this) {
    AppVisibility.BOTH -> true
    AppVisibility.HIDDEN -> false
    AppVisibility.PROFILE_1_ONLY -> profile == Profile.PROFILE_1
    AppVisibility.PROFILE_2_ONLY -> profile == Profile.PROFILE_2
}
