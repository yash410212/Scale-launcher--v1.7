package com.scaleui.launcher.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The concrete visual tokens any glass-styled surface needs. ThemeEngine
 * resolves a [ThemeMode] to one of these; GlassSurface reads it and draws
 * accordingly. Screens never branch on ThemeMode directly — they only
 * ever consume a GlassConfig, so adding a 5th theme later means adding
 * one more `when` branch in ThemeEngine, not touching any screen.
 */
data class GlassConfig(
    val backgroundTint: Color,
    val tintAlpha: Float,
    val blurRadius: Dp,
    val borderColor: Color,
    val borderWidth: Dp,
    val cornerRadius: Dp,
    /**
     * Part 8: Liquid Glass's reference image ("Clear/iOS" concept) has a
     * diagonal light streak across the surface — real refractive glass,
     * not just a flat tint. Rather than special-case ThemeMode inside
     * GlassSurface, this flag says "draw that streak" so any future theme
     * (or Custom) can opt into the same look.
     */
    val hasSpecularHighlight: Boolean = false,
    /**
     * Part 9: the "Glass" reference images (colorful translucent cards +
     * component sheet) show a soft glossy highlight in one corner rather
     * than Liquid Glass's full diagonal streak — a smaller, rounder catch
     * of light. Same pattern as hasSpecularHighlight: a flag GlassSurface
     * reacts to, not a ThemeMode check.
     */
    val hasCornerHighlight: Boolean = false,
    /**
     * Part 10: the "Blur/One UI" reference has soft, diffused edges rather
     * than a crisp border or glossy highlight — a gentle vignette (center
     * clear, edges slightly more tinted) reads as "misty" the way a hard
     * edge wouldn't. Same opt-in-flag pattern as the other two highlights.
     */
    val hasMistVignette: Boolean = false,
    /** Extra optical layers used by the Liquid Glass/iOS-like treatment. */
    val hasRefractionEdge: Boolean = false,
    val surfaceGlowAlpha: Float = 0.0f,
    val innerHighlightAlpha: Float = 0.0f,
    /** Extra icon-slot treatment used by the iOS-like Liquid Glass theme. */
    val iconSlotAlpha: Float = 0.0f,
    val iconSlotBorderAlpha: Float = 0.0f,
    val iconSlotShadowAlpha: Float = 0.0f,
    /** Theme accent used for selected controls and subtle optical color bleed. */
    val accentColor: Color = Color.White,
    /** Surface shadow strength, kept as a token so light themes do not over-shadow. */
    val shadowAlpha: Float = 0.18f,
    /** Very subtle colored sheen behind the main highlight. */
    val accentSheenAlpha: Float = 0.0f,
) {
    companion object {
        /** Used before ThemeEngine has resolved anything (first-frame default). */
        val Fallback = GlassConfig(
            backgroundTint = Color.Black,
            tintAlpha = 0.25f,
            blurRadius = 0.dp,
            borderColor = Color.White,
            borderWidth = 0.dp,
            cornerRadius = 20.dp,
            hasRefractionEdge = false,
            surfaceGlowAlpha = 0.0f,
            innerHighlightAlpha = 0.0f,
        )
    }
}
