package com.scaleui.launcher.folders

import com.scaleui.launcher.core.apps.AppInfo

/** A folder of apps. `id` used as a stable key across recompositions/nav. */
data class ScaleFolder(
    val id: String,
    val name: String,
    val apps: List<AppInfo>,
)
