package com.scaleui.launcher.core.admin

import android.app.admin.DeviceAdminReceiver

/**
 * Empty on purpose — exists so the OS lets Scale UI become a Device Admin,
 * which is what unlocks DevicePolicyManager.lockNow() for Double-Tap-to-Lock
 * (spec section 7). User must grant this once via
 * ACTION_ADD_DEVICE_ADMIN; the lock gesture just no-ops if not granted.
 */
class ScaleDeviceAdminReceiver : DeviceAdminReceiver()
