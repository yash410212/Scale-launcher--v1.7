package com.scaleui.launcher.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.toBitmapCached
import com.scaleui.launcher.theme.LocalIconShape
import com.scaleui.launcher.theme.LocalGlassConfig
import com.scaleui.launcher.theme.LocalThemeMode
import com.scaleui.launcher.theme.ThemeMode

/**
 * A single home-screen icon: app image + label underneath, tap to launch.
 *
 * Part 11: the icon is now clipped to `LocalIconShape.current` (Settings >
 * Home Screen Controls > Icon Shape) instead of always rendering the raw
 * (usually square/adaptive) system icon — same shape source DrawerIcon
 * reads, so Home and Drawer always match.
 */
@Composable
fun HomeIcon(
    app: AppInfo,
    onClick: (AppInfo) -> Unit,
    modifier: Modifier = Modifier,
) {
    val bitmap = remember(app.packageName) { app.icon.toBitmapCached() }
    val shape = LocalIconShape.current.toComposeShape()
    val theme = LocalThemeMode.current
    val liquid = theme == ThemeMode.LIQUID_GLASS
    val glass = LocalGlassConfig.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pressScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        label = "homeIconPress",
    )

    Column(
        modifier = modifier.clickable(interactionSource = interactionSource, indication = androidx.compose.foundation.LocalIndication.current) { onClick(app) }.scale(pressScale),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(if (liquid) 53.dp else 52.dp)
                .shadow(
                    if (liquid) 4.dp else 1.dp,
                    shape,
                    clip = false,
                    ambientColor = Color.Black.copy(alpha = if (liquid) glass.iconSlotShadowAlpha else glass.iconSlotShadowAlpha.coerceAtLeast(0.08f)),
                    spotColor = Color.Black.copy(alpha = if (liquid) glass.iconSlotShadowAlpha + 0.04f else glass.iconSlotShadowAlpha + 0.04f),
                )
                .clip(shape)
                .background(
                    Color.White.copy(alpha = glass.iconSlotAlpha.coerceAtLeast(if (liquid) 0.105f else 0.06f)),
                    shape,
                )
                .border(
                    if (liquid) 1.0.dp else 0.8.dp,
                    Color.White.copy(alpha = glass.iconSlotBorderAlpha.coerceAtLeast(if (liquid) 0.38f else 0.16f)),
                    shape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = BitmapPainter(bitmap.asImageBitmap()),
                contentDescription = app.label,
                modifier = Modifier.size(if (liquid) 45.dp else 44.dp).clip(shape),
            )
        }
        Text(
            text = app.label,
            style = MaterialTheme.typography.labelSmall.copy(
                shadow = if (liquid) androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.28f), blurRadius = 1.5f) else null,
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.size(width = 68.dp, height = 15.dp),
        )
    }
}
