package com.scaleui.launcher.core.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.scaleui.launcher.core.apps.AppRepository
import com.scaleui.launcher.data.SettingsRepository
import com.scaleui.launcher.drawer.AppDrawerScreen
import com.scaleui.launcher.drawer.AppDrawerViewModel
import com.scaleui.launcher.home.HomePagerViewModel
import com.scaleui.launcher.home.HomeScreen
import com.scaleui.launcher.profiles.ProfileManager
import com.scaleui.launcher.settings.SettingsScreen
import com.scaleui.launcher.settings.SettingsViewModel
import com.scaleui.launcher.zeroscreen.ZeroScreenScreen
import com.scaleui.launcher.zeroscreen.ZeroScreenViewModel

private const val ROUTE_HOME = "home"
private const val ROUTE_DRAWER = "drawer"
private const val ROUTE_SETTINGS = "settings"
private const val ROUTE_ZERO_SCREEN = "zero_screen"

/** Four destinations: Home, App Drawer, Settings, Zero Screen. */
@Composable
fun ScaleNavHost(appRepository: AppRepository, settingsRepository: SettingsRepository) {
    val navController: NavHostController = rememberNavController()

    NavHost(navController = navController, startDestination = ROUTE_HOME) {
        composable(ROUTE_HOME) {
            val viewModel: HomePagerViewModel = viewModel(
                factory = factoryFor { HomePagerViewModel(appRepository, settingsRepository) },
            )
            HomeScreen(
                viewModel = viewModel,
                settingsRepository = settingsRepository,
                onOpenDrawer = { navController.navigate(ROUTE_DRAWER) },
                onOpenSettings = { navController.navigate(ROUTE_SETTINGS) },
                onOpenZeroScreen = { navController.navigate(ROUTE_ZERO_SCREEN) },
            )
        }
        composable(
            ROUTE_DRAWER,
            enterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Up, tween(260)) + fadeIn(tween(180)) },
            exitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Down, tween(220)) + fadeOut(tween(140)) },
            popEnterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Down, tween(220)) + fadeIn(tween(140)) },
            popExitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Down, tween(220)) + fadeOut(tween(140)) },
        ) {
            val viewModel: AppDrawerViewModel = viewModel(
                factory = factoryFor { AppDrawerViewModel(appRepository, settingsRepository) },
            )
            AppDrawerScreen(
                viewModel = viewModel,
                onClose = { navController.popBackStack() },
            )
        }
        composable(ROUTE_SETTINGS) {
            val settingsViewModel: SettingsViewModel = viewModel(factory = factoryFor { SettingsViewModel(settingsRepository) })
            val profileManager: ProfileManager = viewModel(factory = factoryFor { ProfileManager(settingsRepository) })
            val installedApps by appRepository.installedApps.collectAsState()
            SettingsScreen(viewModel = settingsViewModel, profileManager = profileManager, settingsRepository = settingsRepository, apps = installedApps)
        }
        composable(
            ROUTE_ZERO_SCREEN,
            enterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(280)) + fadeIn(tween(180)) },
            exitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(240)) + fadeOut(tween(150)) },
            popEnterTransition = { slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(240)) + fadeIn(tween(150)) },
            popExitTransition = { slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(240)) + fadeOut(tween(150)) },
        ) {
            val viewModel: ZeroScreenViewModel = viewModel(factory = factoryFor { ZeroScreenViewModel(settingsRepository) })
            ZeroScreenScreen(viewModel = viewModel, onClose = { navController.popBackStack() })
        }
    }
}

private fun <T : ViewModel> factoryFor(create: () -> T): ViewModelProvider.Factory =
    object : ViewModelProvider.Factory {
        override fun <VM : ViewModel> create(modelClass: Class<VM>): VM {
            @Suppress("UNCHECKED_CAST")
            return create() as VM
        }
    }
