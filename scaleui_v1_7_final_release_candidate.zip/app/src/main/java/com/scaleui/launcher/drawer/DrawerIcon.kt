package com.scaleui.launcher.drawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.toBitmapCached
import com.scaleui.launcher.theme.LocalIconShape
import com.scaleui.launcher.theme.LocalGlassConfig
import com.scaleui.launcher.theme.LocalThemeMode
import com.scaleui.launcher.theme.ThemeMode

/**
 * App Drawer icon per the locked final design: white-background icon slot
 * (Pixel-style), label below. [slotShape] defaults from Settings' icon
 * shape (Part 11).
 *
 * Part 17/20: long-press triggers [onLongPress] (visibility/hidden menu +
 * freeze toggle — AppDrawerScreen owns the actual menu UI). [isFrozen]
 * dims the icon and shows a small lock badge (Part 20's App Freezer is a
 * launcher-level soft freeze — real per-app process freezing needs
 * Device Owner privileges a normal launcher doesn't have).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DrawerIcon(
    app: AppInfo,
    onClick: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit = {},
    isFrozen: Boolean = false,
    modifier: Modifier = Modifier,
    slotShape: Shape = LocalIconShape.current.toComposeShape(),
) {
    val bitmap = remember(app.packageName) { app.icon.toBitmapCached() }
    val liquid = LocalThemeMode.current == ThemeMode.LIQUID_GLASS
    val glass = LocalGlassConfig.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val pressScale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        label = "drawerIconPress",
    )

    Column(
        modifier = modifier.combinedClickable(
            interactionSource = interactionSource,
            indication = androidx.compose.foundation.LocalIndication.current,
            onClick = { onClick(app) },
            onLongClick = { onLongPress(app) },
        ).scale(pressScale),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(if (liquid) 53.dp else 52.dp)
                .shadow(
                    if (liquid) 4.dp else 1.dp,
                    slotShape,
                    clip = false,
                    ambientColor = Color.Black.copy(alpha = if (liquid) glass.iconSlotShadowAlpha else glass.iconSlotShadowAlpha.coerceAtLeast(0.08f)),
                    spotColor = Color.Black.copy(alpha = if (liquid) glass.iconSlotShadowAlpha + 0.04f else glass.iconSlotShadowAlpha + 0.04f),
                )
                .clip(slotShape)
                .background(
                    Color.White.copy(alpha = (glass.iconSlotAlpha + if (liquid) 0.02f else 0.035f).coerceIn(0f, 0.24f)),
                    slotShape,
                )
                .border(
                    if (liquid) 1.0.dp else 0.8.dp,
                    Color.White.copy(alpha = glass.iconSlotBorderAlpha.coerceAtLeast(if (liquid) 0.36f else 0.12f)),
                    slotShape,
                )
                .alpha(if (isFrozen) 0.4f else 1f),
            contentAlignment = Alignment.Center,
        ) {
            Image(
                painter = BitmapPainter(bitmap.asImageBitmap()),
                contentDescription = app.label,
                modifier = Modifier.size(if (liquid) 43.dp else 42.dp).padding(2.dp),
            )
            if (isFrozen) {
                Box(
                    Modifier
                        .size(20.dp)
                        .align(Alignment.BottomEnd)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = .92f))
                        .border(.7.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = .22f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.Lock,
                        contentDescription = "Frozen",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f),
                        modifier = Modifier.size(12.dp),
                    )
                }
            }
        }
        Text(
            text = app.label,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp).size(width = 72.dp, height = 16.dp),
        )
    }
}
