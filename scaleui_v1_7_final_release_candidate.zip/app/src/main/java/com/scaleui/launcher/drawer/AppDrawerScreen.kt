package com.scaleui.launcher.drawer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.scaleui.launcher.core.apps.AppInfo
import com.scaleui.launcher.core.apps.AppLauncher
import com.scaleui.launcher.profiles.AppVisibility
import com.scaleui.launcher.theme.GlassSurface
import kotlinx.coroutines.launch

/**
 * Entry point for the App Drawer, locked design: 5-column grid, white
 * icon slots, A-Z strip. Part 5: search + transparency. Part 7: real
 * GlassSurface background. Part 17/20: long-press an icon opens a small
 * menu (profile visibility + freeze toggle); tapping a frozen app asks to
 * unfreeze instead of launching straight away.
 */
@Composable
fun AppDrawerScreen(
    viewModel: AppDrawerViewModel,
    onClose: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val apps by viewModel.filteredApps.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val transparency by viewModel.transparency.collectAsState()
    val frozenApps by viewModel.frozenApps.collectAsState()
    val gridState = rememberLazyGridState()
    val coroutineScope = rememberCoroutineScope()
    var showTransparencyControl by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }

    val firstIndexForLetter = remember(apps) {
        val map = LinkedHashMap<Char, Int>()
        apps.forEachIndexed { index, app -> map.putIfAbsent(app.sortKey, index) }
        map
    }
    val availableLetters = remember(firstIndexForLetter) { firstIndexForLetter.keys.toList() }

    GlassSurface(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var drag = 0f
                var dispatched = false
                detectVerticalDragGestures(
                    onDragStart = { drag = 0f; dispatched = false },
                    onVerticalDrag = { change, amount ->
                        drag += amount
                        if (!dispatched && drag > 120f) {
                            dispatched = true
                            change.consume()
                            onClose()
                        }
                    },
                    onDragEnd = { drag = 0f },
                    onDragCancel = { drag = 0f },
                )
            },
        shape = RectangleShape,
        alphaOverride = transparency,
    ) {
        BackHandler(enabled = menuApp != null) { menuApp = null }

        Column(modifier = Modifier.fillMaxSize()) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                DrawerSearchBar(query = searchQuery, onQueryChange = viewModel::onSearchQueryChange, modifier = Modifier.weight(1f))
                Icon(
                    imageVector = Icons.Filled.Tune,
                    contentDescription = "Drawer transparency",
                    tint = LocalContentColor.current.copy(alpha = 0.7f),
                    modifier = Modifier.padding(end = 16.dp).clip(RoundedCornerShape(50))
                        .clickable { showTransparencyControl = !showTransparencyControl },
                )
            }

            if (showTransparencyControl) {
                Slider(value = transparency, onValueChange = viewModel::onTransparencyChange, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp))
            }

            Row(modifier = Modifier.fillMaxSize()) {
                if (apps.isEmpty()) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxSize(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Filled.SearchOff,
                                contentDescription = null,
                                tint = LocalContentColor.current.copy(alpha = .46f),
                                modifier = Modifier.size(28.dp),
                            )
                            Text(
                                text = if (searchQuery.isBlank()) "No apps available" else "No matching apps",
                                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                                color = LocalContentColor.current.copy(alpha = .58f),
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(5),
                        state = gridState,
                        modifier = Modifier.weight(1f).fillMaxSize().padding(horizontal = 8.dp, vertical = 8.dp),
                    ) {
                        items(apps, key = { it.packageName }) { app: AppInfo ->
                            val isFrozen = frozenApps.contains(app.packageName)
                            DrawerIcon(
                                app = app,
                                isFrozen = isFrozen,
                                onClick = {
                                    if (isFrozen) menuApp = app else AppLauncher.launch(context, app)
                                },
                                onLongPress = { menuApp = app },
                            )
                        }
                    }
                }

                AZScrollBar(
                    availableLetters = availableLetters,
                    onLetterSelected = { letter ->
                        val index = firstIndexForLetter[letter] ?: return@AZScrollBar
                        coroutineScope.launch { gridState.animateScrollToItem(index) }
                    },
                )
            }
        }

        menuApp?.let { app ->
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.5f))
                    .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { menuApp = null },
                contentAlignment = Alignment.Center,
            ) {
                AppContextMenu(
                    app = app,
                    isFrozen = frozenApps.contains(app.packageName),
                    onSetVisibility = { viewModel.setAppVisibility(app.packageName, it); menuApp = null },
                    onToggleFrozen = { viewModel.toggleFrozen(app.packageName); menuApp = null },
                    onDismiss = { menuApp = null },
                )
            }
        }
    }
}

@Composable
private fun AppContextMenu(
    app: AppInfo,
    isFrozen: Boolean,
    onSetVisibility: (AppVisibility) -> Unit,
    onToggleFrozen: () -> Unit,
    onDismiss: () -> Unit,
) {
    GlassSurface(
        modifier = Modifier.fillMaxWidth(0.8f).padding(24.dp),
        alphaOverride = 0.85f,
    ) {
        Column(modifier = Modifier.padding(16.dp).clickable(onClick = {})) {
            Text(app.label, style = androidx.compose.material3.MaterialTheme.typography.titleMedium)
            listOf(
                "Show in both profiles" to { onSetVisibility(AppVisibility.BOTH) },
                "Profile 1 only" to { onSetVisibility(AppVisibility.PROFILE_1_ONLY) },
                "Profile 2 only" to { onSetVisibility(AppVisibility.PROFILE_2_ONLY) },
                "Hide from all" to { onSetVisibility(AppVisibility.HIDDEN) },
                (if (isFrozen) "Unfreeze" else "Freeze") to onToggleFrozen,
                "Cancel" to onDismiss,
            ).forEach { (label, action) ->
                Text(
                    text = label,
                    style = androidx.compose.material3.MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp).clickable { action() },
                )
            }
        }
    }
}
