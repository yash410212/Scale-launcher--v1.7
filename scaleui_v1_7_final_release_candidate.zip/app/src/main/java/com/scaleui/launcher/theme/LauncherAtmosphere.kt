package com.scaleui.launcher.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** A very light optical layer behind the launcher UI. It keeps the wallpaper visible
 * while adding the depth/colour separation expected from a polished glass launcher. */
@Composable
fun LauncherAtmosphere(modifier: Modifier = Modifier) {
    val mode = LocalThemeMode.current
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val h = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val brush = when (mode) {
        ThemeMode.LIQUID_GLASS -> Brush.radialGradient(
            colors = listOf(Color.White.copy(alpha = .035f), Color.Transparent),
            center = Offset(0.28f * w, 0.12f * h),
            radius = 850f,
        )
        ThemeMode.FROST_GLASS -> Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = .045f), Color.Transparent),
        )
        ThemeMode.GLASS -> Brush.radialGradient(
            colors = listOf(Color.Black.copy(alpha = .12f), Color.Transparent),
            center = Offset(0.5f * w, 0.5f * h),
            radius = 1100f,
        )
        ThemeMode.BLUR_MIST -> Brush.radialGradient(
            colors = listOf(Color.Black.copy(alpha = .12f), Color.Transparent),
            center = Offset(0.5f * w, 0.5f * h),
            radius = 1250f,
        )
        ThemeMode.CUSTOM -> Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = .025f), Color.Transparent),
        )
    }
        Box(modifier = Modifier.fillMaxSize().background(brush))
    }
}
