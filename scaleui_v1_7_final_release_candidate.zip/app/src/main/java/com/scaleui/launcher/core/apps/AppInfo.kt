package com.scaleui.launcher.core.apps

import android.graphics.drawable.Drawable

/**
 * Represents one launchable app on the device, as shown in the App Drawer
 * and (once placed) on the Home Screen.
 *
 * `isFrozen` and profile-visibility fields are NOT here — those live in
 * Room (profiles/AppVisibility, special/AppFreezer) added in a later part,
 * keyed by [packageName]. This class stays a plain, cheap-to-build snapshot
 * of what PackageManager reports.
 */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityClassName: String,
    val icon: Drawable,
) {
    /** Used by the App Drawer's A-Z scroll (added in a later part). */
    val sortKey: Char
        get() = label.firstOrNull()?.uppercaseChar() ?: '#'
}
