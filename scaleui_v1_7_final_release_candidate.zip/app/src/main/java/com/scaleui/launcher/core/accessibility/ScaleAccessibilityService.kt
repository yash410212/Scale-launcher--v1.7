package com.scaleui.launcher.core.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Minimal accessibility bridge used only for the optional Home swipe-down
 * notification-panel gesture. It does not retrieve window content or inspect
 * user data. Android requires the user to enable this service manually.
 */
class ScaleAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        private var instance: ScaleAccessibilityService? = null

        fun openNotificationPanel(): Boolean =
            instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) == true

        fun isConnected(): Boolean = instance != null
    }
}
