@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Use Android Studio/Gradle 8.6 or the included GitHub Actions workflow.
exit /b 1
