# Scale UI — v1.7.0 Final Polish / Release Candidate

Status: **Feature-complete and polished; real-device test phase remains.**

## Final polish pass
- Bumped app version to 1.7.0 / versionCode 9.
- Removed an unused Compose state import from HomeIcon.
- Preserved the locked visual direction and existing feature set; no design-reset or speculative feature changes.
- Kept Home, Zero Screen, App Drawer, Settings, profiles, themes, widgets, wallpaper and gesture architecture intact.
- Kept Liquid Glass/Frost Glass/Glass/Blur Mist styling tuned for restrained overdraw and crisp text/icons.
- Kept app drawer transparent/traditional with search and A–Z navigation.
- Kept real Android AppWidgetHost integration and stale-widget safeguards.
- Kept profile-specific custom wallpaper support and existing PIN protection.

## Test phase checklist
1. Install as default launcher.
2. Verify cold start and Activity recreation.
3. Test Home swipe-up/down/left/right gestures.
4. Test app launch, icon press, long-press and drag/drop.
5. Test App Drawer search, A–Z strip, open/close animation.
6. Test Zero Screen navigation and widgets.
7. Add/remove a real Android system widget and recreate Activity.
8. Test wallpaper selection and profile switching/PIN.
9. Test every theme and animation mode.
10. Test on 60/90 Hz behavior, touch latency, memory pressure and rotation/restart where supported.

## Build note
The project is intended for GitHub Actions using Gradle 8.6 + JDK 17. Local Android compilation is not claimed here; the final validation gate is the user's GitHub Actions build plus real-device testing.
